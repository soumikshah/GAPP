    insert into usertypes(role,roletype,id) values('Administrator','Responsible for managing and dept and users.',1);
    insert into usertypes(role, roletype,id) values('Staff','Responsible for reviewing and updating all applications',2);
    insert into usertypes(role, roletype,id) values('Student','Apply for programs',3);
    
    insert into users(email,enabled,firstname,lastname,password,usertype_id,id) values('admin@localhost.localdomain',true,'John','Doe','abcd',1,1);
    insert into users(email,enabled,firstname,lastname,password,usertype_id,id) values('staff1@localhost.localdomain',true,'Jane','Doe','abcd',2,2);
    insert into users(email,enabled,firstname,lastname,password,usertype_id,id)values('staff2@localhost.localdomain',true,'Joe','Doe','abcd',2,3);
    insert into users(email,enabled,firstname,lastname,password,usertype_id,id)values('student1@localhost.localdomain',true,'Jose','Doe','abcd',3,4);
    insert into users(email,enabled,firstname,lastname,password,usertype_id,id)values('student2@localhost.localdomain',true,'James','Doe','abcd',3,5);

    insert into basicdetails(cin, citizenship,dob,email,firstname,gender,lastname,phonenumber,id)values(1234567,'India','1992-04-02','admin@localhost.localdomain','John','Male','Doe',1232233,1);    
    insert into basicdetails(cin, citizenship,dob,email,firstname,gender,lastname,phonenumber,id) values(1234568,'India','1990-04-02','staff1@localhost.localdomain','Joe','Female','Doe',1232233,2);    
    insert into basicdetails(cin, citizenship,dob,email,firstname,gender,lastname,phonenumber,id) values(1234569,'India','1994-04-02','staff2@localhost.localdomain','Jane','Female','Doe',1232245,3);
    insert into basicdetails(cin, citizenship,dob,email,firstname,gender,lastname,phonenumber,id) values(123555,'India','1989-04-02','student1@localhost.localdomain','Jose','Male','Doe',1232133,4);
    insert into basicdetails(cin, citizenship,dob,email,firstname,gender,lastname,phonenumber,id) values(1234545,'India','1992-01-02','student2@localhost.localdomain','James','Male','Doe',1223233,5);
    
   insert into department (id,name) values(1,'Accounting');
   insert into department (id,name) values(2,'Computer Science');
  
   insert into program(id,name,department_id) values(1,'Masters',1);
   insert into program(id,name,department_id) values(2,'Masters',2);
   
   insert into department_program(department_id,programs_id) values(1,1);
   insert into department_program(department_id,programs_id) values(2,2);
   
   insert into additionaldetails(id,fieldname,requirement,type) values (1,'GMAT scores',true,'Scores');
 	
   insert into department_additionaldetails(department_id,details_id) values(1,1);
   
   INSERT INTO public.education_background(id, major, nameofcollege, timeattendedfrom, timeattendedtill, degreesreceived) VALUES (1, 'Accounting','ABC College of Commerce', '01-02-2010', '01-06-2013','Diploma in Accounting');
   
   insert into applications(id,term,basicdetails_id,department_id,program_id) values(1,'Fall 16',4,1,1);
   
   insert into applications_education_background(applications_id,educationalbackground_id) values(1,1);
   
   insert into applications_usertypes(applications_id,usertypes_id) values(1,3);
       
   insert into appstatus(id,comments,date,status) values(1,'Submitting',NOW(),'New');
   
   insert into usertypes_applications(usertypes_id,application_id) values(3,1);
       
   insert into usertypes_department(usertypes_id,department_id) values (3,1);
           
   insert into usertypes_education_background(usertypes_id,degree_id) values(3,1);
               
   insert into usertypes_program(usertypes_id,programs_id) values(3,1);
                   
   insert into usertypes_users(usertypes_id,users_id) values(3,4);
   