package springmvc.model.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTransactionalTestNGSpringContextTests;
import org.testng.annotations.Test;

@Test(groups = "UserTypeDaoTest")
@ContextConfiguration(locations = "classpath:applicationContext.xml")
public class UserTypeDaoTest extends AbstractTransactionalTestNGSpringContextTests {
	@Autowired
	UserTypeDao usertypeDao;

	@Test
	public void getUserType() {
		for (int i = 0; i > usertypeDao.getUserType().size(); i++) {

			assert usertypeDao.getUserType().get(i).getUsers() != null;
			System.out.println("usertype dao"+usertypeDao.getUserType().get(1).getUsers());

		}
	}
}
