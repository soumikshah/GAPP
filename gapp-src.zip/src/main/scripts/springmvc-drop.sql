drop table authorities;
drop table users;

drop sequence hibernate_sequence;